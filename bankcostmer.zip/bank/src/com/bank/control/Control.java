package com.bank.control;

import java.sql.SQLException;
import java.util.List;

import com.bank.costmerModule.Custmer;
import com.bank.service.Servicebank;

public class Control {
		public static void inserte(Custmer c) throws ClassNotFoundException, SQLException {
			Servicebank.inser(c);
		}
		public static void addbalace(Custmer c) throws ClassNotFoundException, SQLException {
			Servicebank.update(c);
		}
		public static void removebalace(Custmer c) throws ClassNotFoundException, SQLException {
			Servicebank.downdate(c);
		}
		public static List<Custmer> seeall() throws ClassNotFoundException, SQLException {
			List<Custmer> c = Servicebank.fet();
			return c;
		}
		
}

