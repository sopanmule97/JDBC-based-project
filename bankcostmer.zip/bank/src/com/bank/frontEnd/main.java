package com.bank.frontEnd;

import java.sql.SQLException;
import java.util.List;

import com.bank.control.Control;
import com.bank.costmerModule.Custmer;

public class main {
	

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Custmer c= new Custmer("ravi patil", 1223, 156, 6900);
		Control.inserte(c);	
		
		Custmer c1= new Custmer("ravi patil", 100);
		Control.addbalace(c);
		
		List<Custmer> res= Control.seeall();
		for (Custmer aa : res) {
			System.out.println(aa.getName());
			System.out.println(aa.getAcNo());
			System.out.println(aa.getAdhar());
			System.out.println(aa.getBalance());
			System.out.println("****************************");
		}
	}

}
