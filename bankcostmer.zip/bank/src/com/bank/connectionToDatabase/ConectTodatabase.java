package com.bank.connectionToDatabase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.bank.costmerModule.Custmer;

public class ConectTodatabase {
	
	public static Connection conn() throws ClassNotFoundException, SQLException {
		String url= "jdbc:mysql://localhost:3306/aman";
		String username= "root";
		String passward = "root";
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection(url,username,passward);
		return con;
	}
public static int prebalace(Custmer c) throws ClassNotFoundException, SQLException{
		int a=0;
		String query= "select * from bank where name=?";
		Connection con = ConectTodatabase.conn();
		PreparedStatement stm = con.prepareStatement(query);
		stm.setString(1,c.getName() );
		ResultSet res = stm.executeQuery();
		while (res.next()) {	
			a= res.getInt("balance");
		}
		
		return a;
}
	
}
