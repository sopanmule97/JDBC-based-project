package com.bank.service;

import java.sql.SQLException;
import java.util.List;
import com.bank.Dao.DaoBank;
import com.bank.costmerModule.Custmer;

public class Servicebank {
	public static void inser(Custmer c) throws ClassNotFoundException, SQLException {
		DaoBank.AddNewCust(c);
	}
	public static void update(Custmer c) throws ClassNotFoundException, SQLException {
		int a=c.getBalance();
		DaoBank.changebalace(c);
	}
	public static void downdate(Custmer c) throws ClassNotFoundException, SQLException {
		int a=c.getBalance();
		c.setBalance(-a);
		DaoBank.changebalace(c);
	}
	public static List<Custmer> fet() throws ClassNotFoundException, SQLException {
		List<Custmer> a =DaoBank.fetch();
		return a;
	}
	
}
