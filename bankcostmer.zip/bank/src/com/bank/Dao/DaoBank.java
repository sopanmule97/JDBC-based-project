package com.bank.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bank.connectionToDatabase.ConectTodatabase;
import com.bank.costmerModule.Custmer;

public class DaoBank {
	public static void AddNewCust(Custmer c) throws ClassNotFoundException, SQLException{
		
			String query= "insert into bank (name,adhar,AcNo,balance) values (?,?,?,?)";
			Connection con = ConectTodatabase.conn();
			PreparedStatement stm = con.prepareStatement(query);
			stm.setString(1,c.getName() );
			stm.setInt(2,c.getAdhar() );
			stm.setInt(3, c.getAcNo());
			stm.setInt(4, c.getBalance());
			int raw = stm.executeUpdate();
			System.out.println(raw+" is yes add");
	}
	
	public static void changebalace(Custmer c) throws ClassNotFoundException, SQLException{
		int a= ConectTodatabase.prebalace(c)+c.getBalance();
		String query= "update bank set balance =? where name = ? ";
		Connection con = ConectTodatabase.conn();
		PreparedStatement stm = con.prepareStatement(query);
		stm.setInt(1, a);
		stm.setString(2,c.getName() );
		int raw = stm.executeUpdate();
		System.out.println(raw + " balace is updated in "+c.getName());
}
	public static List<Custmer> fetch() throws ClassNotFoundException, SQLException{
		List<Custmer> c= new ArrayList<Custmer>();
		String query= "select * from bank";
		Connection con = ConectTodatabase.conn();
		PreparedStatement stm = con.prepareStatement(query);
		ResultSet res= stm.executeQuery();
		while(res.next()) {
			String name=res.getString("name");
			int AcNo=res.getInt("AcNo");
			int Adhar=res.getInt("adhar");
			int balance= res.getInt("balance");
			Custmer c1= new Custmer(name,  AcNo, Adhar, balance);
			c.add(c1);
		}
		return c;
}
	
}
