package com.bank.costmerModule;

public class Custmer {
		private String name;
		private int AcNo ;
		private int adhar;
		private int balance;
		public Custmer(String name, int acNo, int adhar, int balance) {
			super();
			this.name = name;
			AcNo = acNo;
			this.adhar = adhar;
			this.balance = balance;
		}
		
		public Custmer(String name, int balance) {
			super();
			this.name = name;
			this.balance = balance;
		}

		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public int getAcNo() {
			return AcNo;
		}
		public void setAcNo(int acNo) {
			AcNo = acNo;
		}
		public int getAdhar() {
			return adhar;
		}
		public void setAdhar(int adhar) {
			this.adhar = adhar;
		}
		public int getBalance() {
			return balance;
		}
		public void setBalance(int balance) {
			this.balance = balance;
		}
		
		
		
}
