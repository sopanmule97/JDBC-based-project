package com.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.dao.Dao;
import com.module.Staff;

public class Service {
	
	public ArrayList<Staff> fetchStatement() throws ClassNotFoundException, SQLException {
		Dao dd= new Dao();
		ArrayList<Staff> ss=dd.fetchStatement();
		return ss;
	}
	public ArrayList<Staff> fetchPreparedStatement() throws ClassNotFoundException, SQLException {
		Dao dd= new Dao();
		ArrayList<Staff> st=dd.fetchPreparedStatement();
		return st;
	}
	public  String insertStatement() throws ClassNotFoundException, SQLException {
		Dao dd= new Dao();
		String str=dd.insertStatement();
		return str;
	}
	public String insertPreparedStatement(Staff s) throws ClassNotFoundException, SQLException {
		Dao dd= new Dao();
		String str=dd.insertPreparedStatement(s);
		return str;
	}
	public String updateStatement() throws ClassNotFoundException, SQLException {
		Dao dd= new Dao();
		String st=dd.updateStatement();
		return st;
	}
	public String updatePreparedStatement(Staff s) throws ClassNotFoundException, SQLException {
		Dao dd= new Dao();
		String str=dd.updatePreparedStatement(s);
		return str;
	}
	public String deleteStatement() throws ClassNotFoundException, SQLException {
		Dao dd= new Dao();
		String st=dd.deleteStatement();
		return st;
	}
	public String deletePreparedStatement(Staff s) throws ClassNotFoundException, SQLException {
		Dao dd= new Dao();
		String str=dd.deletePreparedStatement(s);
		return str;
		
	}
	/*	
	*/
}
