package com.module;

public class Staff {
		int Id;
		String name;
		String salary;
		String des;
		
		public Staff() {
			super();
		}
		
		public Staff(int id, String salary) {
			super();
			Id = id;
			this.salary = salary;
		}

		public Staff(int id, String name, String salary, String des) {
			super();
			Id = id;
			this.name = name;
			this.salary = salary;
			this.des = des;
		}
		public int getId() {
			return Id;
		}
		public void setId(int id) {
			Id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getSalary() {
			return salary;
		}
		public void setSalary(String salary) {
			this.salary = salary;
		}
		public String getDes() {
			return des;
		}
		public void setDes(String des) {
			this.des = des;
		}
		@Override
		public String toString() {
			return "Staff [Id=" + Id + ", name=" + name + ", salary=" + salary + ", des=" + des + "]";
		}
		
}
