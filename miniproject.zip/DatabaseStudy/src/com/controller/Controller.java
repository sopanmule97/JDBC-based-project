package com.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.module.Staff;
import com.service.Service;

public class Controller {
	public void fetchStatement() throws ClassNotFoundException, SQLException {
		Service ss= new Service();
		ArrayList<Staff> st=ss.fetchStatement();
		System.out.println(st);
	}
	public void fetchPreparedStatement() throws ClassNotFoundException, SQLException {
		Service ss= new Service();
		ArrayList<Staff>st=ss.fetchPreparedStatement();
		System.out.println(st);
	}
	 public  String insertStatement() throws ClassNotFoundException, SQLException {
		 Service ss= new Service();
		 String s=ss.insertStatement();
		return s;
		
	}
	public void insertPreparedStatement() throws ClassNotFoundException, SQLException {
		Staff s= new Staff(444,"sham","2000","bsss");
		Service ss= new Service();
		String str=ss.insertPreparedStatement(s);
		System.out.println(str);
		
	}
	public void updateStatement() throws ClassNotFoundException, SQLException {
		Staff s= new Staff(1, "200");
		Service ss= new Service();
		String str=ss.updateStatement();
		System.out.println(str);
		
	}
	public void updatePreparedStatement() throws ClassNotFoundException, SQLException {
		Staff s= new Staff(1, "200");
		Service ss= new Service();
		String str=ss.updatePreparedStatement(s);
		System.out.println(str);
		
	}
	public void deleteStatement() throws ClassNotFoundException, SQLException {
		Service s= new Service();
		String st=s.deleteStatement();
		System.out.println(st);
	}
	public void deletePreparedStatement() throws ClassNotFoundException, SQLException {
		Staff s= new Staff(444, "200");
		Service ss= new Service();
		String str=ss.deletePreparedStatement(s);
		System.out.println(str);
	}
	public static void main(String[] args) {
		
	 System.out.println("sd");
		
	}
}
