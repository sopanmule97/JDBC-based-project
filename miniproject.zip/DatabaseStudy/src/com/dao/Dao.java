package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.module.Staff;

public class Dao {
	
	public ArrayList<Staff> fetchStatement() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		String query1="jdbc:mysql://localhost:3306/aman";
		Connection con= DriverManager.getConnection(query1,"root","root");
		Statement stm= con.createStatement();
		String query2= "select * from staff";
		ResultSet rs= stm.executeQuery(query2);
		ArrayList<Staff> al= new ArrayList<Staff>();
		while(rs.next()) {
			int id= rs.getInt(1);
			String name=rs.getString("name");
			String salary= rs.getString(3);
			String des=rs.getString("des");
			Staff s= new Staff();
			s.setId(id);
			s.setDes(des);
			s.setName(name);
			s.setSalary(salary);
			al.add(s);
		}
		return al;
	}
	public ArrayList<Staff> fetchPreparedStatement() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		String query1="jdbc:mysql://localhost:3306/aman";
		Connection con= DriverManager.getConnection(query1,"root","root");
		PreparedStatement stm=con.prepareStatement(query1);
		String query2= "select * from staff";
		ResultSet rs= stm.executeQuery(query2);
		ArrayList<Staff> al= new ArrayList<Staff>();
		while(rs.next()) {
			int id= rs.getInt(1);
			String name=rs.getString("name");
			String salary= rs.getString(3);
			String des=rs.getString("des");
			Staff s= new Staff();
			s.setId(id);
			s.setDes(des);
			s.setName(name);
			s.setSalary(salary);
			al.add(s);
		}
		return al;
	}
	public  String insertStatement() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		String query1="jdbc:mysql://localhost:3306/aman";
		Connection con= DriverManager.getConnection(query1,"root","root");
		Statement stm= con.createStatement();
		String query2= "insert into Staff (Id,name,salary,des) values(11,'ram','2000','mec')";
		int raw = stm.executeUpdate(query2);
		String st="data is not inserted Sucucessfully";
		if(raw==1) {
			st="data inserted Sucucessfully";
		}
		return st;
	}
	public  String insertPreparedStatement(Staff s) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		String query1="jdbc:mysql://localhost:3306/aman";
		Connection con= DriverManager.getConnection(query1,"root","root");
		String query2= "insert into Staff(Id,name,salary,des) values(?,?,?,?)";
		PreparedStatement stm= con.prepareStatement(query2);
		stm.setInt(1, s.getId());
		stm.setString(2, s.getName());
		stm.setString(3, s.getSalary());
		stm.setString(4, s.getDes());
		
		int raw = stm.executeUpdate();
		
		String st="data is not inserted Sucucessfully";
		if(raw==1) {
			st="data inserted Sucucessfully";
		}
		return st;
	}
	public String updateStatement() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		String query1="jdbc:mysql://localhost:3306/aman";
		Connection con= DriverManager.getConnection(query1,"root","root");
		Statement stm= con.createStatement();
		String query2= "update Staff set name='aman' where Id=1";
		int raw = stm.executeUpdate(query2);
		String st="data is not update Sucucessfully";
		if(raw==1) {
			st="data update Sucucessfully";
		}
		return st;
	}
	public String updatePreparedStatement(Staff s) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		String query1="jdbc:mysql://localhost:3306/aman";
		Connection con= DriverManager.getConnection(query1,"root","root");
		String query2= "update Staff set salary=? where Id=?";
		PreparedStatement stm= con.prepareStatement(query2);
		stm.setString(1, s.getSalary());
		System.out.println(s.getSalary());
		stm.setInt(2, s.getId());
		int raw = stm.executeUpdate();
		
		String st="data is not updated Sucucessfully";
		if(raw==1) {
			st="data updated Sucucessfully";
		}
		return st;
	}
	public String deleteStatement() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		String query1="jdbc:mysql://localhost:3306/aman";
		Connection con= DriverManager.getConnection(query1,"root","root");
		Statement stm= con.createStatement();
		String query2= "delete from Staff where Id=2";
		int raw = stm.executeUpdate(query2);
		String st="data is not daleted Sucucessfully";
		if(raw==1) {
			st="data deleted Sucucessfully";
		}
		return st;
	}
	public String deletePreparedStatement(Staff s) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		String query1="jdbc:mysql://localhost:3306/aman";
		Connection con= DriverManager.getConnection(query1,"root","root");
		String query2= "delete from Staff where Id=?";
		PreparedStatement stm= con.prepareStatement(query2);
		stm.setInt(1, s.getId());
		int raw = stm.executeUpdate();
		String st="data is not daleted Sucucessfully";
		if(raw==1) {
			st="data deleted Sucucessfully";
		}
		return st;
	}
	
	

//	public static void main(String[] args) throws ClassNotFoundException, SQLException {
//		Dao dd= new Dao();
//		Staff s= new Staff(151, "kgtf", "1120", "kjf");
//		System.out.println(dd.insertPreparedStatement(s));
//		
//	}
}
